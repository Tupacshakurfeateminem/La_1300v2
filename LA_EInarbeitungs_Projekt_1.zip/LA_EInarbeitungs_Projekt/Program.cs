﻿using System;

namespace LA_EInarbeitungs_Projekt
{
    class Program
    {
        static void Main(string[] args)
        {
            StartGame();
        }

        static void StartGame()
        {
            Random rnd = new Random();
            int secretNumber = rnd.Next(1, 101);

            try
            {
                int attempts = 0;

                while (true)
                {
                    Console.WriteLine("Gebn Sie eine Zahl zwischen 1 und 100 ein");
                    if (!int.TryParse(Console.ReadLine(), out int guessedNumber))
                    {
                        Console.WriteLine("Ungültige Eingabe. Bitte geben Sie eine Zahl zwischen 1 und 100 ein.");
                        continue;
                    }

                    attempts++;

                    if (guessedNumber == secretNumber)
                    {
                        Console.WriteLine($"Herzlichen Glückwunsch! Sie haben die Geheimzahl {secretNumber} erraten.");
                        Console.WriteLine($"Anzahl der Versuche: {attempts}");
                        Console.WriteLine("Möchten Sie weiterspielen? (j/n):");
                        string playAgain = Console.ReadLine();

                        if (playAgain.ToLower() == "j" )
                        {
                            StartGame(); // Starte das Spiel erneut
                        }
                        else
                        {
                            Environment.Exit(0);
                        }
                    }
                    else if (guessedNumber < secretNumber)
                    {
                        Console.WriteLine("Die geratene Zahl ist zu klein.");
                    }
                    else if (guessedNumber > secretNumber)
                    {
                        Console.WriteLine("Die geratene Zahl ist zu groß.");
                    }
                }
            }
            catch
            {
                Console.WriteLine("Ein Fehler ist aufgetreten.");
                Environment.Exit(1);
            }
        }
    }
}
